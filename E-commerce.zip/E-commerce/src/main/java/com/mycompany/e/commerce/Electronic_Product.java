/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;

/**
 *
 * @author nourh
 */
public class Electronic_Product extends product {
    String brand;
 int warranty_Period;
 public Electronic_Product( int product_Id, String name, float price,String 
brand, int warranty_Period) {
 super(product_Id,name,price);
 this.brand = brand;
 this.warranty_Period = Math.abs(warranty_Period);
 
 }
 
 public String getBrand() {
 return brand;
 }
 public void setBrand(String brand) {
 this.brand = brand;
 }
 public int getWarranty_Period() {
 return Math.abs(warranty_Period);
 }
 public void setWarranty_Period(int warranty_Period) {
 if(warranty_Period>0)
 this.warranty_Period = warranty_Period;
 else{
 this.warranty_Period = warranty_Period;
 Math.abs(warranty_Period);
 }
 }
}


