/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;

import javax.swing.JOptionPane;

/**
 *
 * @author nourh
 */
public class Cart {
     int customer_id2;
 static int n_products;
 product[] products;
Cart(int customer_id2,  int n_products) {
 this.customer_id2 = customer_id2;
 this.n_products = n_products;
 
 this.products=new product[n_products];
 }
 public int getCustomer_id() {
 return this.customer_id2;
 }
 public void setCustomer_id(int customer_id) {
 this.customer_id2 = customer_id;
 }
 public int getN_products() {
 return n_products;
 }
 public void setN_products(int n_products) {
 this.n_products = n_products;
 }
 public product[] getProducts() {
 return products;
 }
 public void setProducts(product[] products) {
 this.products = products;
 }
 public void add_product(product p){
products[n_products-1]=p;
n_products--;
 }
 public void remove_product(int productIndex) {
 if (productIndex < 0 || productIndex >= n_products) {
 System.out.println("Invalid product index. Cannot remove product.");
 return;
 }
 for (int i = productIndex; i < n_products - 1; i++) {
 products[i] = products[i + 1];
 }
 n_products--; 
}
 public float calculate_price(){
 float sum=0;
 for(product p:products){
 sum+=p.getPrice();
 }
 return sum;
 }
 public void placeorder(){
 Order o=new Order(customer_id2,1,products,calculate_price());
 o.printinfo(); 
 }
}
