/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;

/**
 *
 * @author nourh
 */
public class product {
     int product_Id;
 String name;
 float price;
 public product(int product_Id, String name, float price) {
 this.product_Id = Math.abs(product_Id);
 this.name = name;
 this.price = price;
 }
 
 public int getProduct_Id() {
 return Math.abs(product_Id);
 }
 public void setProduct_Id(int product_Id) {
 if(product_Id>0){
 this.product_Id = product_Id;
 
 }
 else{
 Math.abs(product_Id);
 this.product_Id = product_Id;
 
 }
 }
 public String getName() {
 return name;
 }
 public void setName(String name) {
 this.name = name;
 }
 public float getPrice() {
 return Math.abs(price);
 }
 public void setPrice(float price) {
 if(price>0)
 this.price = price;
 else{
 Math.abs(price);
 this.price = price;
 
 }
 }
}
