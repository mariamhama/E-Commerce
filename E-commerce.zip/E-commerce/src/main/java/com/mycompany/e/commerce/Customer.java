/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;

/**
 *
 * @author nourh
 */
public class Customer {
   int customer_Id;
 String name_2;
 String address;
 Customer (int customer_Id, String name_2, String address) {
 
 this.customer_Id =Math.abs(customer_Id);
 this.name_2 = name_2;
 this.address = address;
 }
 public int getCustomer_Id() {
 return Math.abs(customer_Id);
 }
 public void setCustomer_Id(int customer_Id) {
 if(customer_Id>0)
 this.customer_Id = customer_Id;
 else{
 Math.abs(customer_Id);
 this.customer_Id = customer_Id;
 }
 }
 public String getName_2() {
 return name_2;
 }
 public void setName_2(String name_2) {
 this.name_2 = name_2;
 }
 public String getAddress() {
 return address;
 }
 public void setAddress(String address) {
 this.address = address;
 }  
}
