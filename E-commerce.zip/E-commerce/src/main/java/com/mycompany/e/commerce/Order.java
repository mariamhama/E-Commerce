/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;
import javax.swing.JOptionPane;
/**
 *
 * @author nourh
 */
public class Order {
    int customer_Id;
 int order_id;
 product[]products;
 float total_price;
 Order(){
     
 }
 
 
 
 public Order(int customer_Id, int order_id, product[] products, float 
total_price) {
 this.customer_Id = Math.abs(customer_Id);
 this.order_id = order_id;
 this.products = products;
 this.total_price = Math.abs(total_price);
 
 }
 public int getCustomer_Id() {
 return Math.abs(customer_Id);
 }
 public void setCustomer_Id(int customer_Id) {
 if(customer_Id>0)
 this.customer_Id = customer_Id;
 else{
 Math.abs(customer_Id);
 this.customer_Id = customer_Id;
 }
 }
 public int getOrder_id() {
 return order_id;
 }
 public void setOrder_id(int order_id) {
 this.order_id = order_id;
 }
 public product[] getProducts() {
 return products;
 }
 public void setProducts(product[] products) {
 this.products = products;
 }
 public float getTotal_price() {
 return Math.abs(total_price);
 }
 public void setTotal_price(float total_price) {
 if(total_price>=0)
 this.total_price = total_price;
 else{
 this.total_price = total_price;
 Math.abs(total_price);
 }
 }

 public void printinfo(){


String message="";
for(int i=0;i<products.length;i++){
    message+=(products[i].getName()+":"+products[i].getPrice()+"\n");
}
JOptionPane.showMessageDialog(null,"Here's your summary: \n"+this.order_id+"\n"+"Customer id: "+this.customer_Id+"\n products: "+"\n "+message+"your total price: "+this.total_price);
 }
}
