/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.e.commerce;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * @author nourh
 */
public class ECommerce {
    public static void main(String[] args) {
 Electronic_Product e=new Electronic_Product(1,"smartphone",(float)599.9,"samsung",1);
 Clothing_product c=new Clothing_product("medium","cotton",2,"t-shirt",(float)19.99);
  Order o=new Order();
 Book_Product b=new Book_Product("o'reilly","x publications",3,"oop",(float)39.99);
 JOptionPane.showMessageDialog(null,"Welcome to E-COMMERCE");
 Scanner sc=new Scanner(System.in);
 int id = Integer.parseInt( JOptionPane.showInputDialog("Enter your id"));
 String name = JOptionPane.showInputDialog("Enter your name");
 String add = JOptionPane.showInputDialog("Enter your address");
 Customer f=new Customer(id,name,add);
 int itemsum = Integer.parseInt( JOptionPane.showInputDialog("How many products you want to add to your cart"));
   Cart cart=new Cart(id,itemsum);
 for(int i=0;i<itemsum;i++){
 int choice = Integer.parseInt( JOptionPane.showInputDialog("Which product would you like to add? 1-smartphone 2-t-shirt 3-oop"));
 switch(choice){
 case 1:
 cart.add_product(e);
 break;
 case 2:
 cart.add_product(c);
 break;
 
 case 3:
 cart.add_product(b);
 break;
 default :
 System.out.println("unavailable choice");
 }
 }
 //System.out.println("your total price: "+cart.calculate_price());
 JOptionPane.showMessageDialog(null,"your total price: "+cart.calculate_price());
// System.out.println("your total price: "+cart.calculate_price());
 int option = Integer.parseInt( JOptionPane.showInputDialog("Would you like to place 1-yes 2-no"));

 switch(option){
 case 1:
 cart.placeorder() ;
 
 break;
 case 2:
 JOptionPane.showMessageDialog(null,"sharftna");
 break;
 }
    }
}

    
